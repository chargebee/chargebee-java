package com.chargebee.v4.models.offerFulfillment.responses;

import com.chargebee.v4.models.offerFulfillment.OfferFulfillment;

import com.chargebee.v4.models.BaseResponse;
import com.chargebee.v4.internal.JsonUtil;
import com.google.gson.JsonObject;
import com.chargebee.v4.transport.Response;

/**
 * Immutable response object for OfferFulfillmentsGet operation. Contains the response data from a
 * single resource get operation.
 */
public final class OfferFulfillmentsGetResponse extends BaseResponse {
  private final OfferFulfillment offerFulfillment;

  private OfferFulfillmentsGetResponse(Builder builder) {
    super(builder.httpResponse);

    this.offerFulfillment = builder.offerFulfillment;
  }

  /** Parse JSON response into OfferFulfillmentsGetResponse object. */
  public static OfferFulfillmentsGetResponse fromJson(String json) {
    return fromJson(json, null);
  }

  /** Parse JSON response into OfferFulfillmentsGetResponse object with HTTP response. */
  public static OfferFulfillmentsGetResponse fromJson(String json, Response httpResponse) {
    try {
      JsonObject jsonObj = JsonUtil.parse(json);
      Builder builder = builder();

      JsonObject __offerFulfillmentObj = JsonUtil.getJsonObject(jsonObj, "offer_fulfillment");
      if (__offerFulfillmentObj != null) {
        builder.offerFulfillment(OfferFulfillment.fromJson(__offerFulfillmentObj));
      }

      builder.httpResponse(httpResponse);
      return builder.build();
    } catch (Exception e) {
      throw new RuntimeException("Failed to parse OfferFulfillmentsGetResponse from JSON", e);
    }
  }

  /** Create a new builder for OfferFulfillmentsGetResponse. */
  public static Builder builder() {
    return new Builder();
  }

  /** Builder for OfferFulfillmentsGetResponse. */
  public static class Builder {

    private OfferFulfillment offerFulfillment;

    private Response httpResponse;

    private Builder() {}

    public Builder offerFulfillment(OfferFulfillment offerFulfillment) {
      this.offerFulfillment = offerFulfillment;
      return this;
    }

    public Builder httpResponse(Response httpResponse) {
      this.httpResponse = httpResponse;
      return this;
    }

    public OfferFulfillmentsGetResponse build() {
      return new OfferFulfillmentsGetResponse(this);
    }
  }

  /** Get the offerFulfillment from the response. */
  public OfferFulfillment getOfferFulfillment() {
    return offerFulfillment;
  }

  @Override
  public String toString() {
    return "OfferFulfillmentsGetResponse{" + "offerFulfillment=" + offerFulfillment + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    OfferFulfillmentsGetResponse that = (OfferFulfillmentsGetResponse) o;
    return java.util.Objects.equals(offerFulfillment, that.offerFulfillment);
  }

  @Override
  public int hashCode() {

    return java.util.Objects.hash(offerFulfillment);
  }
}
