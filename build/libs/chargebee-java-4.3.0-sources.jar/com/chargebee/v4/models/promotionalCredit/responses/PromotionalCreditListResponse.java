package com.chargebee.v4.models.promotionalCredit.responses;

import java.util.List;

import com.chargebee.v4.models.promotionalCredit.PromotionalCredit;

import com.chargebee.v4.exceptions.ChargebeeException;
import com.chargebee.v4.internal.JsonUtil;
import com.google.gson.JsonObject;
import com.chargebee.v4.transport.Response;
import com.chargebee.v4.services.PromotionalCreditService;
import com.chargebee.v4.models.promotionalCredit.params.PromotionalCreditListParams;

/** Immutable response object for PromotionalCreditList operation. Contains paginated list data. */
public final class PromotionalCreditListResponse {

  private final List<PromotionalCreditListItem> list;

  private final String nextOffset;

  private final PromotionalCreditService service;
  private final PromotionalCreditListParams originalParams;
  private final Response httpResponse;

  private PromotionalCreditListResponse(
      List<PromotionalCreditListItem> list,
      String nextOffset,
      PromotionalCreditService service,
      PromotionalCreditListParams originalParams,
      Response httpResponse) {

    this.list = list;

    this.nextOffset = nextOffset;

    this.service = service;
    this.originalParams = originalParams;
    this.httpResponse = httpResponse;
  }

  /**
   * Parse JSON response into PromotionalCreditListResponse object (no service context). Use this
   * when you only need to read a single page (no nextPage()).
   */
  public static PromotionalCreditListResponse fromJson(String json) {
    try {
      JsonObject jsonObj = JsonUtil.parse(json);

      List<PromotionalCreditListItem> list =
          JsonUtil.mapArray(
              JsonUtil.getJsonArray(jsonObj, "list"), PromotionalCreditListItem::fromJson);

      String nextOffset = JsonUtil.getString(jsonObj, "next_offset");

      return new PromotionalCreditListResponse(list, nextOffset, null, null, null);
    } catch (Exception e) {
      throw new RuntimeException("Failed to parse PromotionalCreditListResponse from JSON", e);
    }
  }

  /**
   * Parse JSON response into PromotionalCreditListResponse object with service context for
   * pagination (enables nextPage()).
   */
  public static PromotionalCreditListResponse fromJson(
      String json,
      PromotionalCreditService service,
      PromotionalCreditListParams originalParams,
      Response httpResponse) {
    try {
      JsonObject jsonObj = JsonUtil.parse(json);

      List<PromotionalCreditListItem> list =
          JsonUtil.mapArray(
              JsonUtil.getJsonArray(jsonObj, "list"), PromotionalCreditListItem::fromJson);

      String nextOffset = JsonUtil.getString(jsonObj, "next_offset");

      return new PromotionalCreditListResponse(
          list, nextOffset, service, originalParams, httpResponse);
    } catch (Exception e) {
      throw new RuntimeException("Failed to parse PromotionalCreditListResponse from JSON", e);
    }
  }

  /** Get the list from the response. */
  public List<PromotionalCreditListItem> getList() {
    return list;
  }

  /** Get the nextOffset from the response. */
  public String getNextOffset() {
    return nextOffset;
  }

  /** Check if there are more pages available. */
  public boolean hasNextPage() {
    return nextOffset != null && !nextOffset.isEmpty();
  }

  /**
   * Get the next page of results.
   *
   * @throws ChargebeeException if unable to fetch next page
   */
  public PromotionalCreditListResponse nextPage() throws ChargebeeException {
    if (!hasNextPage()) {
      throw new IllegalStateException("No more pages available");
    }
    if (service == null) {
      throw new UnsupportedOperationException(
          "nextPage() requires service context. Use fromJson(json, service, originalParams, httpResponse).");
    }

    PromotionalCreditListParams nextParams =
        (originalParams != null
                ? originalParams.toBuilder()
                : PromotionalCreditListParams.builder())
            .offset(nextOffset)
            .build();

    return service.list(nextParams);
  }

  /** Get the raw response payload as JSON string. */
  public String responsePayload() {
    return httpResponse != null ? httpResponse.getBodyAsString() : null;
  }

  /** Get the HTTP status code. */
  public int httpStatus() {
    return httpResponse != null ? httpResponse.getStatusCode() : 0;
  }

  /** Get response headers. */
  public java.util.Map<String, java.util.List<String>> headers() {
    return httpResponse != null ? httpResponse.getHeaders() : java.util.Collections.emptyMap();
  }

  /** Get a specific header value. */
  public java.util.List<String> header(String name) {
    if (httpResponse == null) return null;
    return httpResponse.getHeaders().entrySet().stream()
        .filter(e -> e.getKey().equalsIgnoreCase(name))
        .map(java.util.Map.Entry::getValue)
        .findFirst()
        .orElse(null);
  }

  @Override
  public String toString() {
    return "PromotionalCreditListResponse{" + "list=" + list + ", nextOffset=" + nextOffset + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    PromotionalCreditListResponse that = (PromotionalCreditListResponse) o;
    return java.util.Objects.equals(list, that.list)
        && java.util.Objects.equals(nextOffset, that.nextOffset);
  }

  @Override
  public int hashCode() {

    return java.util.Objects.hash(list, nextOffset);
  }

  public static class PromotionalCreditListItem {

    private PromotionalCredit promotionalCredit;

    public PromotionalCredit getPromotionalCredit() {
      return promotionalCredit;
    }

    public static PromotionalCreditListItem fromJson(String json) {
      return fromJson(JsonUtil.parse(json));
    }

    public static PromotionalCreditListItem fromJson(JsonObject jsonObj) {
      PromotionalCreditListItem item = new PromotionalCreditListItem();

      JsonObject __promotionalCreditObj = JsonUtil.getJsonObject(jsonObj, "promotional_credit");
      if (__promotionalCreditObj != null) {
        item.promotionalCredit = PromotionalCredit.fromJson(__promotionalCreditObj);
      }

      return item;
    }

    @Override
    public String toString() {
      return "PromotionalCreditListItem{" + "promotionalCredit=" + promotionalCredit + "}";
    }

    @Override
    public boolean equals(Object o) {
      if (this == o) return true;
      if (o == null || getClass() != o.getClass()) return false;

      PromotionalCreditListItem that = (PromotionalCreditListItem) o;
      return java.util.Objects.equals(promotionalCredit, that.promotionalCredit);
    }

    @Override
    public int hashCode() {

      return java.util.Objects.hash(promotionalCredit);
    }
  }
}
