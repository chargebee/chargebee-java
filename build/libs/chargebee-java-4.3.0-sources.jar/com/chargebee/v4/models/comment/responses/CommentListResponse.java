package com.chargebee.v4.models.comment.responses;

import java.util.List;

import com.chargebee.v4.models.comment.Comment;

import com.chargebee.v4.exceptions.ChargebeeException;
import com.chargebee.v4.internal.JsonUtil;
import com.google.gson.JsonObject;
import com.chargebee.v4.transport.Response;
import com.chargebee.v4.services.CommentService;
import com.chargebee.v4.models.comment.params.CommentListParams;

/** Immutable response object for CommentList operation. Contains paginated list data. */
public final class CommentListResponse {

  private final List<CommentListItem> list;

  private final String nextOffset;

  private final CommentService service;
  private final CommentListParams originalParams;
  private final Response httpResponse;

  private CommentListResponse(
      List<CommentListItem> list,
      String nextOffset,
      CommentService service,
      CommentListParams originalParams,
      Response httpResponse) {

    this.list = list;

    this.nextOffset = nextOffset;

    this.service = service;
    this.originalParams = originalParams;
    this.httpResponse = httpResponse;
  }

  /**
   * Parse JSON response into CommentListResponse object (no service context). Use this when you
   * only need to read a single page (no nextPage()).
   */
  public static CommentListResponse fromJson(String json) {
    try {
      JsonObject jsonObj = JsonUtil.parse(json);

      List<CommentListItem> list =
          JsonUtil.mapArray(JsonUtil.getJsonArray(jsonObj, "list"), CommentListItem::fromJson);

      String nextOffset = JsonUtil.getString(jsonObj, "next_offset");

      return new CommentListResponse(list, nextOffset, null, null, null);
    } catch (Exception e) {
      throw new RuntimeException("Failed to parse CommentListResponse from JSON", e);
    }
  }

  /**
   * Parse JSON response into CommentListResponse object with service context for pagination
   * (enables nextPage()).
   */
  public static CommentListResponse fromJson(
      String json,
      CommentService service,
      CommentListParams originalParams,
      Response httpResponse) {
    try {
      JsonObject jsonObj = JsonUtil.parse(json);

      List<CommentListItem> list =
          JsonUtil.mapArray(JsonUtil.getJsonArray(jsonObj, "list"), CommentListItem::fromJson);

      String nextOffset = JsonUtil.getString(jsonObj, "next_offset");

      return new CommentListResponse(list, nextOffset, service, originalParams, httpResponse);
    } catch (Exception e) {
      throw new RuntimeException("Failed to parse CommentListResponse from JSON", e);
    }
  }

  /** Get the list from the response. */
  public List<CommentListItem> getList() {
    return list;
  }

  /** Get the nextOffset from the response. */
  public String getNextOffset() {
    return nextOffset;
  }

  /** Check if there are more pages available. */
  public boolean hasNextPage() {
    return nextOffset != null && !nextOffset.isEmpty();
  }

  /**
   * Get the next page of results.
   *
   * @throws ChargebeeException if unable to fetch next page
   */
  public CommentListResponse nextPage() throws ChargebeeException {
    if (!hasNextPage()) {
      throw new IllegalStateException("No more pages available");
    }
    if (service == null) {
      throw new UnsupportedOperationException(
          "nextPage() requires service context. Use fromJson(json, service, originalParams, httpResponse).");
    }

    CommentListParams nextParams =
        (originalParams != null ? originalParams.toBuilder() : CommentListParams.builder())
            .offset(nextOffset)
            .build();

    return service.list(nextParams);
  }

  /** Get the raw response payload as JSON string. */
  public String responsePayload() {
    return httpResponse != null ? httpResponse.getBodyAsString() : null;
  }

  /** Get the HTTP status code. */
  public int httpStatus() {
    return httpResponse != null ? httpResponse.getStatusCode() : 0;
  }

  /** Get response headers. */
  public java.util.Map<String, java.util.List<String>> headers() {
    return httpResponse != null ? httpResponse.getHeaders() : java.util.Collections.emptyMap();
  }

  /** Get a specific header value. */
  public java.util.List<String> header(String name) {
    if (httpResponse == null) return null;
    return httpResponse.getHeaders().entrySet().stream()
        .filter(e -> e.getKey().equalsIgnoreCase(name))
        .map(java.util.Map.Entry::getValue)
        .findFirst()
        .orElse(null);
  }

  @Override
  public String toString() {
    return "CommentListResponse{" + "list=" + list + ", nextOffset=" + nextOffset + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    CommentListResponse that = (CommentListResponse) o;
    return java.util.Objects.equals(list, that.list)
        && java.util.Objects.equals(nextOffset, that.nextOffset);
  }

  @Override
  public int hashCode() {

    return java.util.Objects.hash(list, nextOffset);
  }

  public static class CommentListItem {

    private Comment comment;

    public Comment getComment() {
      return comment;
    }

    public static CommentListItem fromJson(String json) {
      return fromJson(JsonUtil.parse(json));
    }

    public static CommentListItem fromJson(JsonObject jsonObj) {
      CommentListItem item = new CommentListItem();

      JsonObject __commentObj = JsonUtil.getJsonObject(jsonObj, "comment");
      if (__commentObj != null) {
        item.comment = Comment.fromJson(__commentObj);
      }

      return item;
    }

    @Override
    public String toString() {
      return "CommentListItem{" + "comment=" + comment + "}";
    }

    @Override
    public boolean equals(Object o) {
      if (this == o) return true;
      if (o == null || getClass() != o.getClass()) return false;

      CommentListItem that = (CommentListItem) o;
      return java.util.Objects.equals(comment, that.comment);
    }

    @Override
    public int hashCode() {

      return java.util.Objects.hash(comment);
    }
  }
}
