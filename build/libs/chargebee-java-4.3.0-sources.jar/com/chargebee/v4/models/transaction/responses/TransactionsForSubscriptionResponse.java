package com.chargebee.v4.models.transaction.responses;

import java.util.List;

import com.chargebee.v4.models.transaction.Transaction;

import com.chargebee.v4.exceptions.ChargebeeException;
import com.chargebee.v4.internal.JsonUtil;
import com.google.gson.JsonObject;
import com.chargebee.v4.transport.Response;
import com.chargebee.v4.services.TransactionService;
import com.chargebee.v4.models.transaction.params.TransactionsForSubscriptionParams;

/**
 * Immutable response object for TransactionsForSubscription operation. Contains paginated list
 * data.
 */
public final class TransactionsForSubscriptionResponse {

  private final List<TransactionTransactionsForSubscriptionItem> list;

  private final String nextOffset;

  private final String subscriptionId;

  private final TransactionService service;
  private final TransactionsForSubscriptionParams originalParams;
  private final Response httpResponse;

  private TransactionsForSubscriptionResponse(
      List<TransactionTransactionsForSubscriptionItem> list,
      String nextOffset,
      String subscriptionId,
      TransactionService service,
      TransactionsForSubscriptionParams originalParams,
      Response httpResponse) {

    this.list = list;

    this.nextOffset = nextOffset;

    this.subscriptionId = subscriptionId;

    this.service = service;
    this.originalParams = originalParams;
    this.httpResponse = httpResponse;
  }

  /**
   * Parse JSON response into TransactionsForSubscriptionResponse object (no service context). Use
   * this when you only need to read a single page (no nextPage()).
   */
  public static TransactionsForSubscriptionResponse fromJson(String json) {
    try {
      JsonObject jsonObj = JsonUtil.parse(json);

      List<TransactionTransactionsForSubscriptionItem> list =
          JsonUtil.mapArray(
              JsonUtil.getJsonArray(jsonObj, "list"),
              TransactionTransactionsForSubscriptionItem::fromJson);

      String nextOffset = JsonUtil.getString(jsonObj, "next_offset");

      return new TransactionsForSubscriptionResponse(list, nextOffset, null, null, null, null);
    } catch (Exception e) {
      throw new RuntimeException(
          "Failed to parse TransactionsForSubscriptionResponse from JSON", e);
    }
  }

  /**
   * Parse JSON response into TransactionsForSubscriptionResponse object with service context for
   * pagination (enables nextPage()).
   */
  public static TransactionsForSubscriptionResponse fromJson(
      String json,
      TransactionService service,
      TransactionsForSubscriptionParams originalParams,
      String subscriptionId,
      Response httpResponse) {
    try {
      JsonObject jsonObj = JsonUtil.parse(json);

      List<TransactionTransactionsForSubscriptionItem> list =
          JsonUtil.mapArray(
              JsonUtil.getJsonArray(jsonObj, "list"),
              TransactionTransactionsForSubscriptionItem::fromJson);

      String nextOffset = JsonUtil.getString(jsonObj, "next_offset");

      return new TransactionsForSubscriptionResponse(
          list, nextOffset, subscriptionId, service, originalParams, httpResponse);
    } catch (Exception e) {
      throw new RuntimeException(
          "Failed to parse TransactionsForSubscriptionResponse from JSON", e);
    }
  }

  /** Get the list from the response. */
  public List<TransactionTransactionsForSubscriptionItem> getList() {
    return list;
  }

  /** Get the nextOffset from the response. */
  public String getNextOffset() {
    return nextOffset;
  }

  /** Check if there are more pages available. */
  public boolean hasNextPage() {
    return nextOffset != null && !nextOffset.isEmpty();
  }

  /**
   * Get the next page of results.
   *
   * @throws ChargebeeException if unable to fetch next page
   */
  public TransactionsForSubscriptionResponse nextPage() throws ChargebeeException {
    if (!hasNextPage()) {
      throw new IllegalStateException("No more pages available");
    }
    if (service == null) {
      throw new UnsupportedOperationException(
          "nextPage() requires service context. Use fromJson(json, service, originalParams, httpResponse).");
    }

    TransactionsForSubscriptionParams nextParams =
        (originalParams != null
                ? originalParams.toBuilder()
                : TransactionsForSubscriptionParams.builder())
            .offset(nextOffset)
            .build();

    return service.transactionsForSubscription(subscriptionId, nextParams);
  }

  /** Get the raw response payload as JSON string. */
  public String responsePayload() {
    return httpResponse != null ? httpResponse.getBodyAsString() : null;
  }

  /** Get the HTTP status code. */
  public int httpStatus() {
    return httpResponse != null ? httpResponse.getStatusCode() : 0;
  }

  /** Get response headers. */
  public java.util.Map<String, java.util.List<String>> headers() {
    return httpResponse != null ? httpResponse.getHeaders() : java.util.Collections.emptyMap();
  }

  /** Get a specific header value. */
  public java.util.List<String> header(String name) {
    if (httpResponse == null) return null;
    return httpResponse.getHeaders().entrySet().stream()
        .filter(e -> e.getKey().equalsIgnoreCase(name))
        .map(java.util.Map.Entry::getValue)
        .findFirst()
        .orElse(null);
  }

  @Override
  public String toString() {
    return "TransactionsForSubscriptionResponse{"
        + "list="
        + list
        + ", nextOffset="
        + nextOffset
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    TransactionsForSubscriptionResponse that = (TransactionsForSubscriptionResponse) o;
    return java.util.Objects.equals(list, that.list)
        && java.util.Objects.equals(nextOffset, that.nextOffset);
  }

  @Override
  public int hashCode() {

    return java.util.Objects.hash(list, nextOffset);
  }

  public static class TransactionTransactionsForSubscriptionItem {

    private Transaction transaction;

    public Transaction getTransaction() {
      return transaction;
    }

    public static TransactionTransactionsForSubscriptionItem fromJson(String json) {
      return fromJson(JsonUtil.parse(json));
    }

    public static TransactionTransactionsForSubscriptionItem fromJson(JsonObject jsonObj) {
      TransactionTransactionsForSubscriptionItem item =
          new TransactionTransactionsForSubscriptionItem();

      JsonObject __transactionObj = JsonUtil.getJsonObject(jsonObj, "transaction");
      if (__transactionObj != null) {
        item.transaction = Transaction.fromJson(__transactionObj);
      }

      return item;
    }

    @Override
    public String toString() {
      return "TransactionTransactionsForSubscriptionItem{" + "transaction=" + transaction + "}";
    }

    @Override
    public boolean equals(Object o) {
      if (this == o) return true;
      if (o == null || getClass() != o.getClass()) return false;

      TransactionTransactionsForSubscriptionItem that =
          (TransactionTransactionsForSubscriptionItem) o;
      return java.util.Objects.equals(transaction, that.transaction);
    }

    @Override
    public int hashCode() {

      return java.util.Objects.hash(transaction);
    }
  }
}
