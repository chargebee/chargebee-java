package com.chargebee.v4.models.coupon.responses;

import com.chargebee.v4.models.coupon.Coupon;

import com.chargebee.v4.models.BaseResponse;
import com.chargebee.v4.internal.JsonUtil;
import com.google.gson.JsonObject;
import com.chargebee.v4.transport.Response;

/** Immutable response object for CouponCopy operation. Contains the response data from the API. */
public final class CouponCopyResponse extends BaseResponse {
  private final Coupon coupon;

  private CouponCopyResponse(Builder builder) {
    super(builder.httpResponse);

    this.coupon = builder.coupon;
  }

  /** Parse JSON response into CouponCopyResponse object. */
  public static CouponCopyResponse fromJson(String json) {
    return fromJson(json, null);
  }

  /** Parse JSON response into CouponCopyResponse object with HTTP response. */
  public static CouponCopyResponse fromJson(String json, Response httpResponse) {
    try {
      JsonObject jsonObj = JsonUtil.parse(json);
      Builder builder = builder();

      JsonObject __couponObj = JsonUtil.getJsonObject(jsonObj, "coupon");
      if (__couponObj != null) {
        builder.coupon(Coupon.fromJson(__couponObj));
      }

      builder.httpResponse(httpResponse);
      return builder.build();
    } catch (Exception e) {
      throw new RuntimeException("Failed to parse CouponCopyResponse from JSON", e);
    }
  }

  /** Create a new builder for CouponCopyResponse. */
  public static Builder builder() {
    return new Builder();
  }

  /** Builder for CouponCopyResponse. */
  public static class Builder {

    private Coupon coupon;

    private Response httpResponse;

    private Builder() {}

    public Builder coupon(Coupon coupon) {
      this.coupon = coupon;
      return this;
    }

    public Builder httpResponse(Response httpResponse) {
      this.httpResponse = httpResponse;
      return this;
    }

    public CouponCopyResponse build() {
      return new CouponCopyResponse(this);
    }
  }

  /** Get the coupon from the response. */
  public Coupon getCoupon() {
    return coupon;
  }

  @Override
  public String toString() {
    return "CouponCopyResponse{" + "coupon=" + coupon + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    CouponCopyResponse that = (CouponCopyResponse) o;
    return java.util.Objects.equals(coupon, that.coupon);
  }

  @Override
  public int hashCode() {

    return java.util.Objects.hash(coupon);
  }
}
