package com.chargebee.v4.models.card.responses;

import com.chargebee.v4.models.customer.Customer;

import com.chargebee.v4.models.BaseResponse;
import com.chargebee.v4.internal.JsonUtil;
import com.google.gson.JsonObject;
import com.chargebee.v4.transport.Response;

/**
 * Immutable response object for DeleteCardForCustomer operation. Contains the response data from
 * the API.
 */
public final class DeleteCardForCustomerResponse extends BaseResponse {
  private final Customer customer;

  private DeleteCardForCustomerResponse(Builder builder) {
    super(builder.httpResponse);

    this.customer = builder.customer;
  }

  /** Parse JSON response into DeleteCardForCustomerResponse object. */
  public static DeleteCardForCustomerResponse fromJson(String json) {
    return fromJson(json, null);
  }

  /** Parse JSON response into DeleteCardForCustomerResponse object with HTTP response. */
  public static DeleteCardForCustomerResponse fromJson(String json, Response httpResponse) {
    try {
      JsonObject jsonObj = JsonUtil.parse(json);
      Builder builder = builder();

      JsonObject __customerObj = JsonUtil.getJsonObject(jsonObj, "customer");
      if (__customerObj != null) {
        builder.customer(Customer.fromJson(__customerObj));
      }

      builder.httpResponse(httpResponse);
      return builder.build();
    } catch (Exception e) {
      throw new RuntimeException("Failed to parse DeleteCardForCustomerResponse from JSON", e);
    }
  }

  /** Create a new builder for DeleteCardForCustomerResponse. */
  public static Builder builder() {
    return new Builder();
  }

  /** Builder for DeleteCardForCustomerResponse. */
  public static class Builder {

    private Customer customer;

    private Response httpResponse;

    private Builder() {}

    public Builder customer(Customer customer) {
      this.customer = customer;
      return this;
    }

    public Builder httpResponse(Response httpResponse) {
      this.httpResponse = httpResponse;
      return this;
    }

    public DeleteCardForCustomerResponse build() {
      return new DeleteCardForCustomerResponse(this);
    }
  }

  /** Get the customer from the response. */
  public Customer getCustomer() {
    return customer;
  }

  @Override
  public String toString() {
    return "DeleteCardForCustomerResponse{" + "customer=" + customer + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    DeleteCardForCustomerResponse that = (DeleteCardForCustomerResponse) o;
    return java.util.Objects.equals(customer, that.customer);
  }

  @Override
  public int hashCode() {

    return java.util.Objects.hash(customer);
  }
}
