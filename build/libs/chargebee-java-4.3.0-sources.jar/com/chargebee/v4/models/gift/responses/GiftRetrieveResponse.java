package com.chargebee.v4.models.gift.responses;

import com.chargebee.v4.models.gift.Gift;

import com.chargebee.v4.models.subscription.Subscription;

import com.chargebee.v4.models.BaseResponse;
import com.chargebee.v4.internal.JsonUtil;
import com.google.gson.JsonObject;
import com.chargebee.v4.transport.Response;

/**
 * Immutable response object for GiftRetrieve operation. Contains the response data from a single
 * resource get operation.
 */
public final class GiftRetrieveResponse extends BaseResponse {
  private final Gift gift;

  private final Subscription subscription;

  private GiftRetrieveResponse(Builder builder) {
    super(builder.httpResponse);

    this.gift = builder.gift;

    this.subscription = builder.subscription;
  }

  /** Parse JSON response into GiftRetrieveResponse object. */
  public static GiftRetrieveResponse fromJson(String json) {
    return fromJson(json, null);
  }

  /** Parse JSON response into GiftRetrieveResponse object with HTTP response. */
  public static GiftRetrieveResponse fromJson(String json, Response httpResponse) {
    try {
      JsonObject jsonObj = JsonUtil.parse(json);
      Builder builder = builder();

      JsonObject __giftObj = JsonUtil.getJsonObject(jsonObj, "gift");
      if (__giftObj != null) {
        builder.gift(Gift.fromJson(__giftObj));
      }

      JsonObject __subscriptionObj = JsonUtil.getJsonObject(jsonObj, "subscription");
      if (__subscriptionObj != null) {
        builder.subscription(Subscription.fromJson(__subscriptionObj));
      }

      builder.httpResponse(httpResponse);
      return builder.build();
    } catch (Exception e) {
      throw new RuntimeException("Failed to parse GiftRetrieveResponse from JSON", e);
    }
  }

  /** Create a new builder for GiftRetrieveResponse. */
  public static Builder builder() {
    return new Builder();
  }

  /** Builder for GiftRetrieveResponse. */
  public static class Builder {

    private Gift gift;

    private Subscription subscription;

    private Response httpResponse;

    private Builder() {}

    public Builder gift(Gift gift) {
      this.gift = gift;
      return this;
    }

    public Builder subscription(Subscription subscription) {
      this.subscription = subscription;
      return this;
    }

    public Builder httpResponse(Response httpResponse) {
      this.httpResponse = httpResponse;
      return this;
    }

    public GiftRetrieveResponse build() {
      return new GiftRetrieveResponse(this);
    }
  }

  /** Get the gift from the response. */
  public Gift getGift() {
    return gift;
  }

  /** Get the subscription from the response. */
  public Subscription getSubscription() {
    return subscription;
  }

  @Override
  public String toString() {
    return "GiftRetrieveResponse{" + "gift=" + gift + ", subscription=" + subscription + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    GiftRetrieveResponse that = (GiftRetrieveResponse) o;
    return java.util.Objects.equals(gift, that.gift)
        && java.util.Objects.equals(subscription, that.subscription);
  }

  @Override
  public int hashCode() {

    return java.util.Objects.hash(gift, subscription);
  }
}
