package com.chargebee.v4.models.itemPrice.responses;

import java.util.List;

import com.chargebee.v4.models.itemPrice.ItemPrice;

import com.chargebee.v4.exceptions.ChargebeeException;
import com.chargebee.v4.internal.JsonUtil;
import com.google.gson.JsonObject;
import com.chargebee.v4.transport.Response;
import com.chargebee.v4.services.ItemPriceService;
import com.chargebee.v4.models.itemPrice.params.FindApplicableItemPricesParams;

/**
 * Immutable response object for FindApplicableItemPrices operation. Contains paginated list data.
 */
public final class FindApplicableItemPricesResponse {

  private final List<ItemPriceFindApplicableItemPricesItem> list;

  private final String nextOffset;

  private final String itemPriceId;

  private final ItemPriceService service;
  private final FindApplicableItemPricesParams originalParams;
  private final Response httpResponse;

  private FindApplicableItemPricesResponse(
      List<ItemPriceFindApplicableItemPricesItem> list,
      String nextOffset,
      String itemPriceId,
      ItemPriceService service,
      FindApplicableItemPricesParams originalParams,
      Response httpResponse) {

    this.list = list;

    this.nextOffset = nextOffset;

    this.itemPriceId = itemPriceId;

    this.service = service;
    this.originalParams = originalParams;
    this.httpResponse = httpResponse;
  }

  /**
   * Parse JSON response into FindApplicableItemPricesResponse object (no service context). Use this
   * when you only need to read a single page (no nextPage()).
   */
  public static FindApplicableItemPricesResponse fromJson(String json) {
    try {
      JsonObject jsonObj = JsonUtil.parse(json);

      List<ItemPriceFindApplicableItemPricesItem> list =
          JsonUtil.mapArray(
              JsonUtil.getJsonArray(jsonObj, "list"),
              ItemPriceFindApplicableItemPricesItem::fromJson);

      String nextOffset = JsonUtil.getString(jsonObj, "next_offset");

      return new FindApplicableItemPricesResponse(list, nextOffset, null, null, null, null);
    } catch (Exception e) {
      throw new RuntimeException("Failed to parse FindApplicableItemPricesResponse from JSON", e);
    }
  }

  /**
   * Parse JSON response into FindApplicableItemPricesResponse object with service context for
   * pagination (enables nextPage()).
   */
  public static FindApplicableItemPricesResponse fromJson(
      String json,
      ItemPriceService service,
      FindApplicableItemPricesParams originalParams,
      String itemPriceId,
      Response httpResponse) {
    try {
      JsonObject jsonObj = JsonUtil.parse(json);

      List<ItemPriceFindApplicableItemPricesItem> list =
          JsonUtil.mapArray(
              JsonUtil.getJsonArray(jsonObj, "list"),
              ItemPriceFindApplicableItemPricesItem::fromJson);

      String nextOffset = JsonUtil.getString(jsonObj, "next_offset");

      return new FindApplicableItemPricesResponse(
          list, nextOffset, itemPriceId, service, originalParams, httpResponse);
    } catch (Exception e) {
      throw new RuntimeException("Failed to parse FindApplicableItemPricesResponse from JSON", e);
    }
  }

  /** Get the list from the response. */
  public List<ItemPriceFindApplicableItemPricesItem> getList() {
    return list;
  }

  /** Get the nextOffset from the response. */
  public String getNextOffset() {
    return nextOffset;
  }

  /** Check if there are more pages available. */
  public boolean hasNextPage() {
    return nextOffset != null && !nextOffset.isEmpty();
  }

  /**
   * Get the next page of results.
   *
   * @throws ChargebeeException if unable to fetch next page
   */
  public FindApplicableItemPricesResponse nextPage() throws ChargebeeException {
    if (!hasNextPage()) {
      throw new IllegalStateException("No more pages available");
    }
    if (service == null) {
      throw new UnsupportedOperationException(
          "nextPage() requires service context. Use fromJson(json, service, originalParams, httpResponse).");
    }

    FindApplicableItemPricesParams nextParams =
        (originalParams != null
                ? originalParams.toBuilder()
                : FindApplicableItemPricesParams.builder())
            .offset(nextOffset)
            .build();

    return service.findApplicableItemPrices(itemPriceId, nextParams);
  }

  /** Get the raw response payload as JSON string. */
  public String responsePayload() {
    return httpResponse != null ? httpResponse.getBodyAsString() : null;
  }

  /** Get the HTTP status code. */
  public int httpStatus() {
    return httpResponse != null ? httpResponse.getStatusCode() : 0;
  }

  /** Get response headers. */
  public java.util.Map<String, java.util.List<String>> headers() {
    return httpResponse != null ? httpResponse.getHeaders() : java.util.Collections.emptyMap();
  }

  /** Get a specific header value. */
  public java.util.List<String> header(String name) {
    if (httpResponse == null) return null;
    return httpResponse.getHeaders().entrySet().stream()
        .filter(e -> e.getKey().equalsIgnoreCase(name))
        .map(java.util.Map.Entry::getValue)
        .findFirst()
        .orElse(null);
  }

  @Override
  public String toString() {
    return "FindApplicableItemPricesResponse{"
        + "list="
        + list
        + ", nextOffset="
        + nextOffset
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    FindApplicableItemPricesResponse that = (FindApplicableItemPricesResponse) o;
    return java.util.Objects.equals(list, that.list)
        && java.util.Objects.equals(nextOffset, that.nextOffset);
  }

  @Override
  public int hashCode() {

    return java.util.Objects.hash(list, nextOffset);
  }

  public static class ItemPriceFindApplicableItemPricesItem {

    private ItemPrice itemPrice;

    public ItemPrice getItemPrice() {
      return itemPrice;
    }

    public static ItemPriceFindApplicableItemPricesItem fromJson(String json) {
      return fromJson(JsonUtil.parse(json));
    }

    public static ItemPriceFindApplicableItemPricesItem fromJson(JsonObject jsonObj) {
      ItemPriceFindApplicableItemPricesItem item = new ItemPriceFindApplicableItemPricesItem();

      JsonObject __itemPriceObj = JsonUtil.getJsonObject(jsonObj, "item_price");
      if (__itemPriceObj != null) {
        item.itemPrice = ItemPrice.fromJson(__itemPriceObj);
      }

      return item;
    }

    @Override
    public String toString() {
      return "ItemPriceFindApplicableItemPricesItem{" + "itemPrice=" + itemPrice + "}";
    }

    @Override
    public boolean equals(Object o) {
      if (this == o) return true;
      if (o == null || getClass() != o.getClass()) return false;

      ItemPriceFindApplicableItemPricesItem that = (ItemPriceFindApplicableItemPricesItem) o;
      return java.util.Objects.equals(itemPrice, that.itemPrice);
    }

    @Override
    public int hashCode() {

      return java.util.Objects.hash(itemPrice);
    }
  }
}
