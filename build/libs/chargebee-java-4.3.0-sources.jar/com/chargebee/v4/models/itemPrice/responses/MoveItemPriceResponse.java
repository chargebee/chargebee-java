package com.chargebee.v4.models.itemPrice.responses;

import com.chargebee.v4.models.itemPrice.ItemPrice;

import com.chargebee.v4.models.BaseResponse;
import com.chargebee.v4.internal.JsonUtil;
import com.chargebee.v4.transport.Response;
import com.google.gson.JsonObject;

/**
 * Immutable response object for MoveItemPrice operation. Contains the response data from the API.
 */
public final class MoveItemPriceResponse extends BaseResponse {
  private final ItemPrice itemPrice;

  private MoveItemPriceResponse(Builder builder) {
    super(builder.httpResponse);

    this.itemPrice = builder.itemPrice;
  }

  /** Parse JSON response into MoveItemPriceResponse object. */
  public static MoveItemPriceResponse fromJson(String json) {
    return fromJson(json, null);
  }

  /** Parse JSON response into MoveItemPriceResponse object with HTTP response. */
  public static MoveItemPriceResponse fromJson(String json, Response httpResponse) {
    try {
      Builder builder = builder();

      JsonObject jsonObj = JsonUtil.parse(json);
      JsonObject __itemPriceObj = JsonUtil.getJsonObject(jsonObj, "item_price");
      if (__itemPriceObj != null) {
        builder.itemPrice(ItemPrice.fromJson(__itemPriceObj));
      }

      builder.httpResponse(httpResponse);
      return builder.build();
    } catch (Exception e) {
      throw new RuntimeException("Failed to parse MoveItemPriceResponse from JSON", e);
    }
  }

  /** Create a new builder for MoveItemPriceResponse. */
  public static Builder builder() {
    return new Builder();
  }

  /** Builder for MoveItemPriceResponse. */
  public static class Builder {

    private ItemPrice itemPrice;

    private Response httpResponse;

    private Builder() {}

    public Builder itemPrice(ItemPrice itemPrice) {
      this.itemPrice = itemPrice;
      return this;
    }

    public Builder httpResponse(Response httpResponse) {
      this.httpResponse = httpResponse;
      return this;
    }

    public MoveItemPriceResponse build() {
      return new MoveItemPriceResponse(this);
    }
  }

  /** Get the itemPrice from the response. */
  public ItemPrice getItemPrice() {
    return itemPrice;
  }

  @Override
  public String toString() {
    return "MoveItemPriceResponse{" + "itemPrice=" + itemPrice + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    MoveItemPriceResponse that = (MoveItemPriceResponse) o;
    return java.util.Objects.equals(itemPrice, that.itemPrice);
  }

  @Override
  public int hashCode() {

    return java.util.Objects.hash(itemPrice);
  }
}
