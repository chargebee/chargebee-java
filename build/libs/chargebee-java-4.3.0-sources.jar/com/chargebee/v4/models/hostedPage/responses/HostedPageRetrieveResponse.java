package com.chargebee.v4.models.hostedPage.responses;

import com.chargebee.v4.models.hostedPage.HostedPage;

import com.chargebee.v4.models.BaseResponse;
import com.chargebee.v4.internal.JsonUtil;
import com.google.gson.JsonObject;
import com.chargebee.v4.transport.Response;

/**
 * Immutable response object for HostedPageRetrieve operation. Contains the response data from a
 * single resource get operation.
 */
public final class HostedPageRetrieveResponse extends BaseResponse {
  private final HostedPage hostedPage;

  private HostedPageRetrieveResponse(Builder builder) {
    super(builder.httpResponse);

    this.hostedPage = builder.hostedPage;
  }

  /** Parse JSON response into HostedPageRetrieveResponse object. */
  public static HostedPageRetrieveResponse fromJson(String json) {
    return fromJson(json, null);
  }

  /** Parse JSON response into HostedPageRetrieveResponse object with HTTP response. */
  public static HostedPageRetrieveResponse fromJson(String json, Response httpResponse) {
    try {
      JsonObject jsonObj = JsonUtil.parse(json);
      Builder builder = builder();

      JsonObject __hostedPageObj = JsonUtil.getJsonObject(jsonObj, "hosted_page");
      if (__hostedPageObj != null) {
        builder.hostedPage(HostedPage.fromJson(__hostedPageObj));
      }

      builder.httpResponse(httpResponse);
      return builder.build();
    } catch (Exception e) {
      throw new RuntimeException("Failed to parse HostedPageRetrieveResponse from JSON", e);
    }
  }

  /** Create a new builder for HostedPageRetrieveResponse. */
  public static Builder builder() {
    return new Builder();
  }

  /** Builder for HostedPageRetrieveResponse. */
  public static class Builder {

    private HostedPage hostedPage;

    private Response httpResponse;

    private Builder() {}

    public Builder hostedPage(HostedPage hostedPage) {
      this.hostedPage = hostedPage;
      return this;
    }

    public Builder httpResponse(Response httpResponse) {
      this.httpResponse = httpResponse;
      return this;
    }

    public HostedPageRetrieveResponse build() {
      return new HostedPageRetrieveResponse(this);
    }
  }

  /** Get the hostedPage from the response. */
  public HostedPage getHostedPage() {
    return hostedPage;
  }

  @Override
  public String toString() {
    return "HostedPageRetrieveResponse{" + "hostedPage=" + hostedPage + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    HostedPageRetrieveResponse that = (HostedPageRetrieveResponse) o;
    return java.util.Objects.equals(hostedPage, that.hostedPage);
  }

  @Override
  public int hashCode() {

    return java.util.Objects.hash(hostedPage);
  }
}
