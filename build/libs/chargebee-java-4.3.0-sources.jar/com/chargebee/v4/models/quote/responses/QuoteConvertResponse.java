package com.chargebee.v4.models.quote.responses;

import java.util.List;

import com.chargebee.v4.models.quote.Quote;

import com.chargebee.v4.models.quotedRamp.QuotedRamp;

import com.chargebee.v4.models.quotedSubscription.QuotedSubscription;

import com.chargebee.v4.models.invoice.Invoice;

import com.chargebee.v4.models.customer.Customer;

import com.chargebee.v4.models.creditNote.CreditNote;

import com.chargebee.v4.models.unbilledCharge.UnbilledCharge;

import com.chargebee.v4.models.quotedCharge.QuotedCharge;

import com.chargebee.v4.models.subscription.Subscription;

import com.chargebee.v4.models.BaseResponse;
import com.chargebee.v4.internal.JsonUtil;
import com.google.gson.JsonObject;
import com.chargebee.v4.transport.Response;

/**
 * Immutable response object for QuoteConvert operation. Contains the response data from the API.
 */
public final class QuoteConvertResponse extends BaseResponse {
  private final Quote quote;

  private final QuotedSubscription quotedSubscription;

  private final QuotedCharge quotedCharge;

  private final QuotedRamp quotedRamp;

  private final Customer customer;

  private final Subscription subscription;

  private final Invoice invoice;

  private final CreditNote creditNote;

  private final List<UnbilledCharge> unbilledCharges;

  private QuoteConvertResponse(Builder builder) {
    super(builder.httpResponse);

    this.quote = builder.quote;

    this.quotedSubscription = builder.quotedSubscription;

    this.quotedCharge = builder.quotedCharge;

    this.quotedRamp = builder.quotedRamp;

    this.customer = builder.customer;

    this.subscription = builder.subscription;

    this.invoice = builder.invoice;

    this.creditNote = builder.creditNote;

    this.unbilledCharges = builder.unbilledCharges;
  }

  /** Parse JSON response into QuoteConvertResponse object. */
  public static QuoteConvertResponse fromJson(String json) {
    return fromJson(json, null);
  }

  /** Parse JSON response into QuoteConvertResponse object with HTTP response. */
  public static QuoteConvertResponse fromJson(String json, Response httpResponse) {
    try {
      JsonObject jsonObj = JsonUtil.parse(json);
      Builder builder = builder();

      JsonObject __quoteObj = JsonUtil.getJsonObject(jsonObj, "quote");
      if (__quoteObj != null) {
        builder.quote(Quote.fromJson(__quoteObj));
      }

      JsonObject __quotedSubscriptionObj = JsonUtil.getJsonObject(jsonObj, "quoted_subscription");
      if (__quotedSubscriptionObj != null) {
        builder.quotedSubscription(QuotedSubscription.fromJson(__quotedSubscriptionObj));
      }

      JsonObject __quotedChargeObj = JsonUtil.getJsonObject(jsonObj, "quoted_charge");
      if (__quotedChargeObj != null) {
        builder.quotedCharge(QuotedCharge.fromJson(__quotedChargeObj));
      }

      JsonObject __quotedRampObj = JsonUtil.getJsonObject(jsonObj, "quoted_ramp");
      if (__quotedRampObj != null) {
        builder.quotedRamp(QuotedRamp.fromJson(__quotedRampObj));
      }

      JsonObject __customerObj = JsonUtil.getJsonObject(jsonObj, "customer");
      if (__customerObj != null) {
        builder.customer(Customer.fromJson(__customerObj));
      }

      JsonObject __subscriptionObj = JsonUtil.getJsonObject(jsonObj, "subscription");
      if (__subscriptionObj != null) {
        builder.subscription(Subscription.fromJson(__subscriptionObj));
      }

      JsonObject __invoiceObj = JsonUtil.getJsonObject(jsonObj, "invoice");
      if (__invoiceObj != null) {
        builder.invoice(Invoice.fromJson(__invoiceObj));
      }

      JsonObject __creditNoteObj = JsonUtil.getJsonObject(jsonObj, "credit_note");
      if (__creditNoteObj != null) {
        builder.creditNote(CreditNote.fromJson(__creditNoteObj));
      }

      builder.unbilledCharges(
          JsonUtil.mapArray(
              JsonUtil.getJsonArray(jsonObj, "unbilled_charges"), UnbilledCharge::fromJson));

      builder.httpResponse(httpResponse);
      return builder.build();
    } catch (Exception e) {
      throw new RuntimeException("Failed to parse QuoteConvertResponse from JSON", e);
    }
  }

  /** Create a new builder for QuoteConvertResponse. */
  public static Builder builder() {
    return new Builder();
  }

  /** Builder for QuoteConvertResponse. */
  public static class Builder {

    private Quote quote;

    private QuotedSubscription quotedSubscription;

    private QuotedCharge quotedCharge;

    private QuotedRamp quotedRamp;

    private Customer customer;

    private Subscription subscription;

    private Invoice invoice;

    private CreditNote creditNote;

    private List<UnbilledCharge> unbilledCharges;

    private Response httpResponse;

    private Builder() {}

    public Builder quote(Quote quote) {
      this.quote = quote;
      return this;
    }

    public Builder quotedSubscription(QuotedSubscription quotedSubscription) {
      this.quotedSubscription = quotedSubscription;
      return this;
    }

    public Builder quotedCharge(QuotedCharge quotedCharge) {
      this.quotedCharge = quotedCharge;
      return this;
    }

    public Builder quotedRamp(QuotedRamp quotedRamp) {
      this.quotedRamp = quotedRamp;
      return this;
    }

    public Builder customer(Customer customer) {
      this.customer = customer;
      return this;
    }

    public Builder subscription(Subscription subscription) {
      this.subscription = subscription;
      return this;
    }

    public Builder invoice(Invoice invoice) {
      this.invoice = invoice;
      return this;
    }

    public Builder creditNote(CreditNote creditNote) {
      this.creditNote = creditNote;
      return this;
    }

    public Builder unbilledCharges(List<UnbilledCharge> unbilledCharges) {
      this.unbilledCharges = unbilledCharges;
      return this;
    }

    public Builder httpResponse(Response httpResponse) {
      this.httpResponse = httpResponse;
      return this;
    }

    public QuoteConvertResponse build() {
      return new QuoteConvertResponse(this);
    }
  }

  /** Get the quote from the response. */
  public Quote getQuote() {
    return quote;
  }

  /** Get the quotedSubscription from the response. */
  public QuotedSubscription getQuotedSubscription() {
    return quotedSubscription;
  }

  /** Get the quotedCharge from the response. */
  public QuotedCharge getQuotedCharge() {
    return quotedCharge;
  }

  /** Get the quotedRamp from the response. */
  public QuotedRamp getQuotedRamp() {
    return quotedRamp;
  }

  /** Get the customer from the response. */
  public Customer getCustomer() {
    return customer;
  }

  /** Get the subscription from the response. */
  public Subscription getSubscription() {
    return subscription;
  }

  /** Get the invoice from the response. */
  public Invoice getInvoice() {
    return invoice;
  }

  /** Get the creditNote from the response. */
  public CreditNote getCreditNote() {
    return creditNote;
  }

  /** Get the unbilledCharges from the response. */
  public List<UnbilledCharge> getUnbilledCharges() {
    return unbilledCharges;
  }

  @Override
  public String toString() {
    return "QuoteConvertResponse{"
        + "quote="
        + quote
        + ", quotedSubscription="
        + quotedSubscription
        + ", quotedCharge="
        + quotedCharge
        + ", quotedRamp="
        + quotedRamp
        + ", customer="
        + customer
        + ", subscription="
        + subscription
        + ", invoice="
        + invoice
        + ", creditNote="
        + creditNote
        + ", unbilledCharges="
        + unbilledCharges
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    QuoteConvertResponse that = (QuoteConvertResponse) o;
    return java.util.Objects.equals(quote, that.quote)
        && java.util.Objects.equals(quotedSubscription, that.quotedSubscription)
        && java.util.Objects.equals(quotedCharge, that.quotedCharge)
        && java.util.Objects.equals(quotedRamp, that.quotedRamp)
        && java.util.Objects.equals(customer, that.customer)
        && java.util.Objects.equals(subscription, that.subscription)
        && java.util.Objects.equals(invoice, that.invoice)
        && java.util.Objects.equals(creditNote, that.creditNote)
        && java.util.Objects.equals(unbilledCharges, that.unbilledCharges);
  }

  @Override
  public int hashCode() {

    return java.util.Objects.hash(
        quote,
        quotedSubscription,
        quotedCharge,
        quotedRamp,
        customer,
        subscription,
        invoice,
        creditNote,
        unbilledCharges);
  }
}
