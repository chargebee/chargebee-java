package com.chargebee.v4.models.quote.responses;

import com.chargebee.v4.models.quote.Quote;

import com.chargebee.v4.models.quotedSubscription.QuotedSubscription;

import com.chargebee.v4.models.BaseResponse;
import com.chargebee.v4.internal.JsonUtil;
import com.google.gson.JsonObject;
import com.chargebee.v4.transport.Response;

/**
 * Immutable response object for EditUpdateSubscriptionQuote operation. Contains the response data
 * from the API.
 */
public final class EditUpdateSubscriptionQuoteResponse extends BaseResponse {
  private final Quote quote;

  private final QuotedSubscription quotedSubscription;

  private EditUpdateSubscriptionQuoteResponse(Builder builder) {
    super(builder.httpResponse);

    this.quote = builder.quote;

    this.quotedSubscription = builder.quotedSubscription;
  }

  /** Parse JSON response into EditUpdateSubscriptionQuoteResponse object. */
  public static EditUpdateSubscriptionQuoteResponse fromJson(String json) {
    return fromJson(json, null);
  }

  /** Parse JSON response into EditUpdateSubscriptionQuoteResponse object with HTTP response. */
  public static EditUpdateSubscriptionQuoteResponse fromJson(String json, Response httpResponse) {
    try {
      JsonObject jsonObj = JsonUtil.parse(json);
      Builder builder = builder();

      JsonObject __quoteObj = JsonUtil.getJsonObject(jsonObj, "quote");
      if (__quoteObj != null) {
        builder.quote(Quote.fromJson(__quoteObj));
      }

      JsonObject __quotedSubscriptionObj = JsonUtil.getJsonObject(jsonObj, "quoted_subscription");
      if (__quotedSubscriptionObj != null) {
        builder.quotedSubscription(QuotedSubscription.fromJson(__quotedSubscriptionObj));
      }

      builder.httpResponse(httpResponse);
      return builder.build();
    } catch (Exception e) {
      throw new RuntimeException(
          "Failed to parse EditUpdateSubscriptionQuoteResponse from JSON", e);
    }
  }

  /** Create a new builder for EditUpdateSubscriptionQuoteResponse. */
  public static Builder builder() {
    return new Builder();
  }

  /** Builder for EditUpdateSubscriptionQuoteResponse. */
  public static class Builder {

    private Quote quote;

    private QuotedSubscription quotedSubscription;

    private Response httpResponse;

    private Builder() {}

    public Builder quote(Quote quote) {
      this.quote = quote;
      return this;
    }

    public Builder quotedSubscription(QuotedSubscription quotedSubscription) {
      this.quotedSubscription = quotedSubscription;
      return this;
    }

    public Builder httpResponse(Response httpResponse) {
      this.httpResponse = httpResponse;
      return this;
    }

    public EditUpdateSubscriptionQuoteResponse build() {
      return new EditUpdateSubscriptionQuoteResponse(this);
    }
  }

  /** Get the quote from the response. */
  public Quote getQuote() {
    return quote;
  }

  /** Get the quotedSubscription from the response. */
  public QuotedSubscription getQuotedSubscription() {
    return quotedSubscription;
  }

  @Override
  public String toString() {
    return "EditUpdateSubscriptionQuoteResponse{"
        + "quote="
        + quote
        + ", quotedSubscription="
        + quotedSubscription
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    EditUpdateSubscriptionQuoteResponse that = (EditUpdateSubscriptionQuoteResponse) o;
    return java.util.Objects.equals(quote, that.quote)
        && java.util.Objects.equals(quotedSubscription, that.quotedSubscription);
  }

  @Override
  public int hashCode() {

    return java.util.Objects.hash(quote, quotedSubscription);
  }
}
