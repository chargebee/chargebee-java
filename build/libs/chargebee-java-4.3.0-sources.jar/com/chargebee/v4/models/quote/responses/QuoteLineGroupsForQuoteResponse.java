package com.chargebee.v4.models.quote.responses;

import java.util.List;

import com.chargebee.v4.models.quoteLineGroup.QuoteLineGroup;

import com.chargebee.v4.exceptions.ChargebeeException;
import com.chargebee.v4.internal.JsonUtil;
import com.google.gson.JsonObject;
import com.chargebee.v4.transport.Response;
import com.chargebee.v4.services.QuoteService;
import com.chargebee.v4.models.quote.params.QuoteLineGroupsForQuoteParams;

/**
 * Immutable response object for QuoteLineGroupsForQuote operation. Contains paginated list data.
 */
public final class QuoteLineGroupsForQuoteResponse {

  private final List<QuoteQuoteLineGroupsForQuoteItem> list;

  private final String nextOffset;

  private final String quoteId;

  private final QuoteService service;
  private final QuoteLineGroupsForQuoteParams originalParams;
  private final Response httpResponse;

  private QuoteLineGroupsForQuoteResponse(
      List<QuoteQuoteLineGroupsForQuoteItem> list,
      String nextOffset,
      String quoteId,
      QuoteService service,
      QuoteLineGroupsForQuoteParams originalParams,
      Response httpResponse) {

    this.list = list;

    this.nextOffset = nextOffset;

    this.quoteId = quoteId;

    this.service = service;
    this.originalParams = originalParams;
    this.httpResponse = httpResponse;
  }

  /**
   * Parse JSON response into QuoteLineGroupsForQuoteResponse object (no service context). Use this
   * when you only need to read a single page (no nextPage()).
   */
  public static QuoteLineGroupsForQuoteResponse fromJson(String json) {
    try {
      JsonObject jsonObj = JsonUtil.parse(json);

      List<QuoteQuoteLineGroupsForQuoteItem> list =
          JsonUtil.mapArray(
              JsonUtil.getJsonArray(jsonObj, "list"), QuoteQuoteLineGroupsForQuoteItem::fromJson);

      String nextOffset = JsonUtil.getString(jsonObj, "next_offset");

      return new QuoteLineGroupsForQuoteResponse(list, nextOffset, null, null, null, null);
    } catch (Exception e) {
      throw new RuntimeException("Failed to parse QuoteLineGroupsForQuoteResponse from JSON", e);
    }
  }

  /**
   * Parse JSON response into QuoteLineGroupsForQuoteResponse object with service context for
   * pagination (enables nextPage()).
   */
  public static QuoteLineGroupsForQuoteResponse fromJson(
      String json,
      QuoteService service,
      QuoteLineGroupsForQuoteParams originalParams,
      String quoteId,
      Response httpResponse) {
    try {
      JsonObject jsonObj = JsonUtil.parse(json);

      List<QuoteQuoteLineGroupsForQuoteItem> list =
          JsonUtil.mapArray(
              JsonUtil.getJsonArray(jsonObj, "list"), QuoteQuoteLineGroupsForQuoteItem::fromJson);

      String nextOffset = JsonUtil.getString(jsonObj, "next_offset");

      return new QuoteLineGroupsForQuoteResponse(
          list, nextOffset, quoteId, service, originalParams, httpResponse);
    } catch (Exception e) {
      throw new RuntimeException("Failed to parse QuoteLineGroupsForQuoteResponse from JSON", e);
    }
  }

  /** Get the list from the response. */
  public List<QuoteQuoteLineGroupsForQuoteItem> getList() {
    return list;
  }

  /** Get the nextOffset from the response. */
  public String getNextOffset() {
    return nextOffset;
  }

  /** Check if there are more pages available. */
  public boolean hasNextPage() {
    return nextOffset != null && !nextOffset.isEmpty();
  }

  /**
   * Get the next page of results.
   *
   * @throws ChargebeeException if unable to fetch next page
   */
  public QuoteLineGroupsForQuoteResponse nextPage() throws ChargebeeException {
    if (!hasNextPage()) {
      throw new IllegalStateException("No more pages available");
    }
    if (service == null) {
      throw new UnsupportedOperationException(
          "nextPage() requires service context. Use fromJson(json, service, originalParams, httpResponse).");
    }

    QuoteLineGroupsForQuoteParams nextParams =
        (originalParams != null
                ? originalParams.toBuilder()
                : QuoteLineGroupsForQuoteParams.builder())
            .offset(nextOffset)
            .build();

    return service.quoteLineGroupsForQuote(quoteId, nextParams);
  }

  /** Get the raw response payload as JSON string. */
  public String responsePayload() {
    return httpResponse != null ? httpResponse.getBodyAsString() : null;
  }

  /** Get the HTTP status code. */
  public int httpStatus() {
    return httpResponse != null ? httpResponse.getStatusCode() : 0;
  }

  /** Get response headers. */
  public java.util.Map<String, java.util.List<String>> headers() {
    return httpResponse != null ? httpResponse.getHeaders() : java.util.Collections.emptyMap();
  }

  /** Get a specific header value. */
  public java.util.List<String> header(String name) {
    if (httpResponse == null) return null;
    return httpResponse.getHeaders().entrySet().stream()
        .filter(e -> e.getKey().equalsIgnoreCase(name))
        .map(java.util.Map.Entry::getValue)
        .findFirst()
        .orElse(null);
  }

  @Override
  public String toString() {
    return "QuoteLineGroupsForQuoteResponse{" + "list=" + list + ", nextOffset=" + nextOffset + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    QuoteLineGroupsForQuoteResponse that = (QuoteLineGroupsForQuoteResponse) o;
    return java.util.Objects.equals(list, that.list)
        && java.util.Objects.equals(nextOffset, that.nextOffset);
  }

  @Override
  public int hashCode() {

    return java.util.Objects.hash(list, nextOffset);
  }

  public static class QuoteQuoteLineGroupsForQuoteItem {

    private QuoteLineGroup quoteLineGroup;

    public QuoteLineGroup getQuoteLineGroup() {
      return quoteLineGroup;
    }

    public static QuoteQuoteLineGroupsForQuoteItem fromJson(String json) {
      return fromJson(JsonUtil.parse(json));
    }

    public static QuoteQuoteLineGroupsForQuoteItem fromJson(JsonObject jsonObj) {
      QuoteQuoteLineGroupsForQuoteItem item = new QuoteQuoteLineGroupsForQuoteItem();

      JsonObject __quoteLineGroupObj = JsonUtil.getJsonObject(jsonObj, "quote_line_group");
      if (__quoteLineGroupObj != null) {
        item.quoteLineGroup = QuoteLineGroup.fromJson(__quoteLineGroupObj);
      }

      return item;
    }

    @Override
    public String toString() {
      return "QuoteQuoteLineGroupsForQuoteItem{" + "quoteLineGroup=" + quoteLineGroup + "}";
    }

    @Override
    public boolean equals(Object o) {
      if (this == o) return true;
      if (o == null || getClass() != o.getClass()) return false;

      QuoteQuoteLineGroupsForQuoteItem that = (QuoteQuoteLineGroupsForQuoteItem) o;
      return java.util.Objects.equals(quoteLineGroup, that.quoteLineGroup);
    }

    @Override
    public int hashCode() {

      return java.util.Objects.hash(quoteLineGroup);
    }
  }
}
