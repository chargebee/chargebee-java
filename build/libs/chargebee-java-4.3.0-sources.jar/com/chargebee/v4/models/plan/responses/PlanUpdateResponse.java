package com.chargebee.v4.models.plan.responses;

import com.chargebee.v4.models.plan.Plan;

import com.chargebee.v4.models.BaseResponse;
import com.chargebee.v4.internal.JsonUtil;
import com.google.gson.JsonObject;
import com.chargebee.v4.transport.Response;

/** Immutable response object for PlanUpdate operation. Contains the response data from the API. */
public final class PlanUpdateResponse extends BaseResponse {
  private final Plan plan;

  private PlanUpdateResponse(Builder builder) {
    super(builder.httpResponse);

    this.plan = builder.plan;
  }

  /** Parse JSON response into PlanUpdateResponse object. */
  public static PlanUpdateResponse fromJson(String json) {
    return fromJson(json, null);
  }

  /** Parse JSON response into PlanUpdateResponse object with HTTP response. */
  public static PlanUpdateResponse fromJson(String json, Response httpResponse) {
    try {
      JsonObject jsonObj = JsonUtil.parse(json);
      Builder builder = builder();

      JsonObject __planObj = JsonUtil.getJsonObject(jsonObj, "plan");
      if (__planObj != null) {
        builder.plan(Plan.fromJson(__planObj));
      }

      builder.httpResponse(httpResponse);
      return builder.build();
    } catch (Exception e) {
      throw new RuntimeException("Failed to parse PlanUpdateResponse from JSON", e);
    }
  }

  /** Create a new builder for PlanUpdateResponse. */
  public static Builder builder() {
    return new Builder();
  }

  /** Builder for PlanUpdateResponse. */
  public static class Builder {

    private Plan plan;

    private Response httpResponse;

    private Builder() {}

    public Builder plan(Plan plan) {
      this.plan = plan;
      return this;
    }

    public Builder httpResponse(Response httpResponse) {
      this.httpResponse = httpResponse;
      return this;
    }

    public PlanUpdateResponse build() {
      return new PlanUpdateResponse(this);
    }
  }

  /** Get the plan from the response. */
  public Plan getPlan() {
    return plan;
  }

  @Override
  public String toString() {
    return "PlanUpdateResponse{" + "plan=" + plan + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    PlanUpdateResponse that = (PlanUpdateResponse) o;
    return java.util.Objects.equals(plan, that.plan);
  }

  @Override
  public int hashCode() {

    return java.util.Objects.hash(plan);
  }
}
